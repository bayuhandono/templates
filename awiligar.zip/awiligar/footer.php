    <footer>
      <p><?php Shield::get('path'); ?></p>
      <p>&#x00A9; <?php echo $date->year; ?> &#x00B7; <a href="<?php echo $url; ?>"><?php echo $site->title; ?></a></p>
    </footer>
  </body>
</html>