<?php

return ['sort' => [1, 'slug']];