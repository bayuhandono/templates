<?php Shield::get('header'); ?>
<main>
  <article id="post-0">
    <header>
      <h2>404 <?php echo $language->_finded; ?></h2>
    </header>
    <section>
      <p>:(</p>
    </section>
  </article>
</main>
<?php Shield::get('footer'); ?>